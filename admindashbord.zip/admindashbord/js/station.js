stationModal = document.getElementById('station-modal');
station_openModal = document.getElementById('open-station');
station_closeModal = document.getElementById('cancel');

station_openModal.onclick = function() {
    stationModal.style.display = "block";
  }
  
  // When the user clicks on <span> (x), close the modal
  station_closeModal.onclick = function() {
    stationModal.style.display = "none";
  }
  
  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    if (event.target == stationModal) {
        stationModal.style.display = "none";
    }
  }

