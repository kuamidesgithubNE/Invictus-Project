driverModal = document.getElementById("driver_modal");
driver_openModal = document.getElementById("driver_open");
driver_closeModal = document.getElementById("cancel");

driver_openModal.onclick = function () {
  driverModal.style.display = "block";
};

// When the user clicks on <span> (x), close the modal
driver_closeModal.onclick = function () {
  driverModal.style.display = "none";
};

// When the user clicks anywhere outside of the modal, close it
window.onclick = function (event) {
  if (event.target == driverModal) {
    driverModal.style.display = "none";
  }
};
