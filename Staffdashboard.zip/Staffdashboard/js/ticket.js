ticketModal = document.getElementById('ticket-modal');
ticket_openModal = document.getElementById('open-ticket');
ticket_closeModal = document.getElementById('cancel');

ticket_openModal.onclick = function() {
    ticketModal.style.display = "block";
  }
  
  // When the user clicks on <span> (x), close the modal
  ticket_closeModal.onclick = function() {
    ticketModal.style.display = "none";
  }
  
  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    if (event.target == ticketModal) {
        ticketModal.style.display = "none";
    }
  }

