<?php

session_start();

if(isset($_SESSION["user_id"])){
    unset($_SESSION["user_id"]);

    //Redirect back to the index page
    header("Location: index.php");
}