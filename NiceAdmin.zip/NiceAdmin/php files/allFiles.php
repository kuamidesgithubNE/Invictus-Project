<?php 
    session_start();

    include("php files/connection.php");
    include("php files/functions.php");
    $user_data = check_login($con);
    $user_id = $user_data["user_id"];

// Variable for the various component 
    $username = " ";
    $fullname = " ";
    $job = " ";
    $company = " ";
    $country = " ";
    $address = " ";
    $phone = " ";
    $email = " ";
    $about = " ";

$sql = "select username,session_id,full_name,about,company,job,country,address,phone,email from users join user_profiles on users.user_id = user_profiles.user_id join user_employment on users.user_id = user_employment.user_id join user_contact_info on users.user_id = user_contact_info.user_id join user_email on users.user_id = user_email.user_id where session_id = '$user_id'";
    $result = $con->query($sql);
    $row = mysqli_fetch_assoc($result);
    $username = $row["username"];
    $fullname = $row["full_name"];
    $about = $row["about"];
    $job = $row["job"];
    $company = $row["company"];
    $country = $row["country"];
    $address = $row["address"];
    $phone = $row["phone"];
    $email = $row["email"];

?>