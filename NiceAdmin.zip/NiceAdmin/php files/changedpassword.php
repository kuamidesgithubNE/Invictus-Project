<?php
session_start();
include("functions.php");
include("connection.php");

$user_data = check_login($con);

$user_id = $user_data["user_id"];

$sql = "select * from users where user_id = '$user_id'";
$result = $con->query($sql);
if($result && $result->num_rows > 0){
$row = mysqli_fetch_assoc($result);
}

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $currentPassword = $_POST["password"];
    $newPassword  = $_POST["newpassword"];
    $renewPassword = $_POST["renewpassword"];
    if(!empty($currentPassword) && !empty($newPassword) && !empty($renewPassword)){
            if($currentPassword == $row["password"]){
                if($renewPassword == $newPassword){
                    $query = "UPDATE users SET password = '$renewPassword' WHERE user_id = '$user_id'";
                    $result1 = $con->query($query);
                    if($result1){
                        echo "Password Update Successful!";
                    }
                    else{
                        echo "Error Updating password!";
                }
            }
             else{
                    echo "Password Mismatch! Try again.";
                }
        }
        else{
            echo "result not found";
        }
    }
    else{
        echo "Fill in the required space";
    }
  }

?>