<?php
include("connection.php");

$sql = "Select * from books where category = '$category'";
$result = $con->query($sql);
