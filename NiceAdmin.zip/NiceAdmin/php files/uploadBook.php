<?php
session_start();
include('connection.php');
include('functions.php');

$user_data = check_login($con);
$user_id = $user_data["user_id"];



if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST["title"];
    $categories = $_POST["categories"];
    $author = $_POST["author"];
    $fileToUpload = $_FILES["fileToUpload"];
    $file_content = file_get_contents($_FILES['fileToUpload']['tmp_name']);
    $file_content = mysqli_real_escape_string($con, $file_content);

    if (!empty($title) && !empty($categories) && !empty($author) && !empty($fileToUpload["name"])) {
        $filename = basename($fileToUpload["name"]);
        $fileExtension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        if (in_array($fileExtension, ["pdf", "pptx", "docx"])) {
            if ($fileToUpload["size"] <= 50000000) {
                // Use prepared statement to insert data
                $stmt = $con->prepare("INSERT INTO books (title, category, author, filename, file_content, user_id) VALUES (?, ?, ?, ?, ?, ?)");
                
                // Bind parameters to the prepared statement
                $stmt->bind_param("sssssi", $title, $categories, $author, $filename, $file_content, $user_id);
        
                // Execute the prepared statement
                if ($stmt->execute()) {
                    echo "File uploaded successfully.";
                } else {
                    echo "File not uploaded.";
                }
        
                // Close the prepared statement
                $stmt->close();
            } else {
                echo "Sorry, your file is too large.";
            }
        } else {
            echo "Sorry, only PDF, PPTX, and DOCX files are allowed.";
        }
    }}        
?>
