<?php
session_start();
include("functions.php");
include("connection.php");

$user_data = check_login($con);

$user_id = $user_data["user_id"];

$sql = "select * from user_profiles  where user_id = '$user_id'";
$sql1 = "select * from user_employment where user_id = '$user_id'";
$sql2 = "select * from user_contact_info where user_id = '$user_id'";
$sql3 = "select * from user_email where user_id = '$user_id'";

$userProfiles = $con->query($sql);
$userEmployment = $con->query($sql1);
$userInfo = $con->query($sql2);
$userEmail = $con->query($sql3);

$userRow = mysqli_num_rows($userProfiles)> 0;
$employmentRow = mysqli_num_rows($userEmployment) > 0;
$infoRow = mysqli_num_rows($userEmail) > 0;
$emailRow =  mysqli_num_rows($userInfo) > 0;

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $fullname = $_POST["fullName"];
    $about  = $_POST["about"];
    $company = $_POST["company"];
    $job = $_POST["job"];
    $country = $_POST["country"];
    $address = $_POST["address"];
    $phone = $_POST["phone"];
    $email = $_POST["email"];
    
    if(!$userRow && !$employmentRow && !$infoRow && !$emailRow){
     
       $query = "insert into user_employment(company,job,user_id) values ('$company','$job','$user_id')";
       $query1 = "insert into user_profiles(full_name,about,user_id,session_id) values ('$fullname','$about','$user_id','$user_id')";
       $query2  =  "insert into user_contact_info(country,address,phone,user_id) values ('$country','$address','$phone','$user_id')";
       $query3  =  "insert into user_email(email,user_id) values ('$email','$user_id')";

        $employment = $con->query($query);
        $profiles = $con->query($query1);
        $contact = $con->query($query2);
        $email = $con->query($query3);

        if($employment && $profiles && $contact && $email){
        echo "Record saved successfully";
        }
        else{
        echo "Record not saved";
        }
    }
    else{
        if(!empty($fullname)){
            $query = "update user_profiles set full_name = '$fullname' where user_id = '$user_id'";
            $update = $con->query($query);
            if($update){
                echo "Update Successfully";
            }
            else{
                echo "Update Unsuccessful";
            }
        }
        elseif(!empty($about)){
            $query = "update user_profiles set about = '$about' where user_id = '$user_id'";
            $update = $con->query($query);
            if($update){
                echo "Update Successfully";
            }
            else{
                echo "Update Unsuccessful";
            }
        }
        elseif(!empty($company)){
            $query = "update user_employment set company = '$company' where user_id = '$user_id'";
            $update = $con->query($query);
            if($update){
                echo "Update Successfully";
            }
            else{
                echo "Update Unsuccessful";
            }
        }
        elseif(!empty($job)){
            $query = "update user_employment set job = '$job' where user_id = '$user_id'";
            $update = $con->query($query);
            if($update){
                echo "Update Successfully";
            }
            else{
                echo "Update Unsuccessful";
            }
        }
        elseif(!empty($country)){
            $query = "update user_contact_info set country = '$country' where user_id = '$user_id'";
            $update = $con->query($query);
            if($update){
                echo "Update Successfully";
            }
            else{
                echo "Update Unsuccessful";
            }
        }
        elseif(!empty($address)){
            $query = "update user_contact_info set address = '$address' where user_id = '$user_id'";
            $update = $con->query($query);
            if($update){
                echo "Update Successfully";
            }
            else{
                echo "Update Unsuccessful";
            }
        }
        elseif(!empty($phone)){
            $query = "update user_contact_info set phone = '$phone' where user_id = '$user_id'";
            $update = $con->query($query);
            if($update){
                echo "Update Successfully";
            }
            else{
                echo "Update Unsuccessful";
            }
        }
        elseif(!empty($email)){
            $query = "update user_email set phone = '$email' where user_id = '$email'";
            $update = $con->query($query);
            if($update){
                echo "Update Successfully";
            }
            else{
                echo "Update Unsuccessful";
            }
        }
    }
     
}
