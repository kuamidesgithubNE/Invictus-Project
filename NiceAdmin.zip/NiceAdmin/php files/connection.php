<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "e_library";
$con = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);
if($con){
   
}else{
    echo "Connection error";
}


?>