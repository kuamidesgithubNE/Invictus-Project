<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>HOME</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

    <div class="d-flex align-items-center justify-content-between">
      <a href="index.php" class="logo d-flex align-items-center">
        <img src="assets/img/logo.png" alt="">
        <span class="d-none d-lg-block">E-LIBRARY</span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div><!-- End Logo -->

    <div class="search-bar">
      <form class="search-form d-flex align-items-center" method="POST" action="#">
        <input type="text" name="query" placeholder="Search" title="Enter search keyword">
        <button type="submit" title="Search"><i class="bi bi-search"></i></button>
      </form>
    </div><!-- End Search Bar -->

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

        <li class="nav-item d-block d-lg-none">
          <a class="nav-link nav-icon search-bar-toggle " href="#">
            <i class="bi bi-search"></i>
          </a>
        </li><!-- End Search Icon-->

      

          

      <div class="col-md-3 text-end d-flex align-items-center">
      <a href="login.php">
        <button type="button" class="btn btn-outline-primary me-2">Login</button>
      </a>
      <a href="register.php">
        <button type="button" class="btn btn-primary">Signup</button>
      </a>  
      </div>
    </nav><!-- End Icons Navigation -->

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link " href="index.php">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li><!-- End Dashboard Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#tables-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-book"></i><span>Books</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="tables-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="table_science.php">
              <i class="bi bi-circle"></i><span>Science</span>
            </a>
          </li>
          <li>
            <a href="table_history.php">
              <i class="bi bi-circle"></i><span>History</span>
            </a>
          </li>
          <li>
            <a href="table_governance.php">
              <i class="bi bi-circle"></i><span>Governance</span>
            </a>
          </li>
          <li>
            <a href="table_economics.php">
              <i class="bi bi-circle"></i><span>Economics</span>
            </a>
          </li>
          <li>
            <a href="table_accounting.php">
              <i class="bi bi-circle"></i><span>Accounting</span>
            </a>
          </li>
          <li>
            <a href="table_fiction.php">
              <i class="bi bi-circle"></i><span>Fiction</span>
            </a>
          </li>
          <li>
            <a href="table_computing.php">
              <i class="bi bi-circle"></i><span>Computing</span>
            </a>
          </li>
          <li>
            <a href="table_health.php">
              <i class="bi bi-circle"></i><span>Health</span>
            </a>
          </li>
        </ul>
      </li><!-- End Book Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#forms-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-camera-reels"></i><span>Video</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="forms-nav" class="nav-content collapse" data-bs-parent="#sidebar-nav">
          <li>
            <a href="vid_science.php">
              <i class="bi bi-circle"></i><span>Science</span>
            </a>
          </li>
          <li>
            <a href="vid_history.php">
              <i class="bi bi-circle"></i><span>History</span>
            </a>
          </li>
          <li>
            <a href="vid_governance.php">
              <i class="bi bi-circle"></i><span>Governance</span>
            </a>
          </li>
          <li>
            <a href="vid_economic.php">
              <i class="bi bi-circle"></i><span>Economics</span>
            </a>
          </li>
          <li>
            <a href="vid_accounting.php">
              <i class="bi bi-circle"></i><span>Accounting</span>
            </a>
          </li>
          <li>
            <a href="vid_fiction.php">
              <i class="bi bi-circle"></i><span>Fiction</span>
            </a>
          </li>
          <li>
            <a href="vid_computing.php">
              <i class="bi bi-circle"></i><span>Computing</span>
            </a>
          </li>
          <li>
            <a href="vid_health.php">
              <i class="bi bi-circle"></i><span>Health</span>
            </a>
          </li>
        </ul>
      </li><!-- End Video Nav -->


      <li class="nav-item">
        <a class="nav-link collapsed" href="profile.php">
          <i class="bi bi-person"></i>
          <span>Profile</span>
        </a>
      </li><!-- End Profile Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="#">
          <i class="bi bi-box-arrow-in-left"></i>
          <span>Logout</span>
        </a>
      </li><!-- End Logout Page Nav -->

    </ul>

  </aside><!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Dashboard</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="home.php">Home</a></li>
        </ol>
        <!---- End-->

      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      
      <!---Edited Portion-->

              <div class="rows">
                 <div class="row-col"><img src="books_pic/1659111317-41d1gVUK1yL._SL500_.jpg"></div>
                 <div class="row-col"><img src="books_pic/3d719618432a7b44048a49d0093550ad.jpg"></div>
                 <div class="row-col"><img src="books_pic/410a519ee915b4b10e331cc0a7600758.jpg"></div>
                 <div class="row-col"><img src="books_pic/417kcv-vhts-sl500--612e87fe16991.jpg"></div>
              </div>

                <div class="rows">
                   <div class="row-col"><img src="books_pic/9780593337783.jpg"></div>
                   <div class="row-col"><img src="books_pic/41ZxW8sQplL._SY300_.jpg"></div>
                   <div class="row-col"><img src="books_pic/439612.jpg"></div>
                   <div class="row-col"><img src="books_pic/49e7f0dac34965a7bc7faacc28595adf.jpg"></div>
             </div>

             <div class="rows">
              <div class="row-col"><img src="books_pic/51PlzHKtSQL._SX314_BO1,204,203,200_.jpg"></div>
              <div class="row-col"><img src="books_pic/58511594.jpg"></div>
              <div class="row-col"><img src="books_pic/cover_issue_890_en_US.jpg"></div>
              <div class="row-col"><img src="books_pic/md_01e2cf7cb346-homebeforedark.jpg"></div>
        </div>

    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>E-LIBRARY</span></strong>. All Rights Reserved
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.umd.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>