addSliceModal = document.getElementById('add-slide-modal');
add_slice_openModal = document.getElementById('open-add-slide');
addSliseCloseModal = document.getElementById('Slidecancel');

add_slice_openModal.onclick = function() {
    addSliceModal.style.display = "block";
  }
  
  // When the user clicks on <span> (x), close the modal
  addSliseCloseModal.onclick = function() {
    addSliceModal.style.display = "none";
  }
  
  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    if (event.target == addSliceModal) {
      addSliceModal.style.display = "none";
    }
  }
