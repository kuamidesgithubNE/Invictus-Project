viewAudio = document.getElementById('view-audio-modal');
view_audio_openModal = document.getElementById('open-view-audio');
viewAudiocloseModal = document.getElementById('viewAudioCancel');

view_audio_openModal.onclick = function() {
    viewAudio.style.display = "block";
  }
  
  // When the user clicks on <span> (x), close the modal
  viewAudiocloseModal.onclick = function() {
    viewAudio.style.display = "none";
  }
  
  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    if (event.target == viewAudio) {
        viewAudio.style.display = "none";
    }
  }
