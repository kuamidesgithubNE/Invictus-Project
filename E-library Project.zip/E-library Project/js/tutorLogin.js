tutorLogin = document.getElementById('tutor-modal-box');
tutor_login_openModal = document.getElementById('open-tutorLogin');

tutor_login_openModal.onclick = function() {
  tutorLogin.style.display = "block";
  }
  
  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    if (event.target == tutorLogin) {
      tutorLogin.style.display = "none";
    }
  }
