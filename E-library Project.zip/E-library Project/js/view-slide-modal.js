viewSlide = document.getElementById('view-slide-modal');
view_slide_openModal = document.getElementById('open-view-slide');
viewSlidecloseModal = document.getElementById('viewSlideCancel');

view_slide_openModal.onclick = function() {
    viewSlide.style.display = "block";
  }
  
  // When the user clicks on <span> (x), close the modal
  viewSlidecloseModal.onclick = function() {
    viewSlide.style.display = "none";
  }
  
  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    if (event.target == viewSlide) {
        viewSlide.style.display = "none";
    }
  }
