resetModal = document.getElementById('reset-modal');
reset_openModal = document.getElementById('open-reset');
resetCloseModal = document.getElementById('resetCancel');

reset_openModal.onclick = function() {
    resetModal.style.display = "block";
  }
  
  // When the user clicks on <span> (x), close the modal
  resetCloseModal.onclick = function() {
    resetModal.style.display = "none";
  }
  
  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    if (event.target == resetModal) {
        resetModal.style.display = "none";
    }
  }
