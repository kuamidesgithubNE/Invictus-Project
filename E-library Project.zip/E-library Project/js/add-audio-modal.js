addAudioModal = document.getElementById('add-audio-modal');
add_audio_openModal = document.getElementById('open-add-audio');
addAudioCloseModal = document.getElementById('AudioCancel');

add_audio_openModal.onclick = function() {
    addAudioModal.style.display = "block";
  }
  
  // When the user clicks on <span> (x), close the modal
  addAudioCloseModal.onclick = function() {
    addAudioModal.style.display = "none";
  }
  
  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    if (event.target == addAudioModal) {
      addAudioModal.style.display = "none";
    }
  }
