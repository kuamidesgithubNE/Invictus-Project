viewCourse = document.getElementById('view-course-modal');
view_course_openModal = document.getElementById('open-view-course');
viewCoursecloseModal = document.getElementById('viewCourseCancel');

view_course_openModal.onclick = function() {
    viewCourse.style.display = "block";
  }
  
  // When the user clicks on <span> (x), close the modal
  viewCoursecloseModal.onclick = function() {
    viewCourse.style.display = "none";
  }
  
  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    if (event.target == viewCourse) {
        viewCourse.style.display = "none";
    }
  }
